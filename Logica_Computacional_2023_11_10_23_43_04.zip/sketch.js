
document.write("Flávio nasceu em " + (2016 - 39));
document.write("<br>");
document.write("Joaquim nasceu em " + (2016 - 20));
document.write("<br>");
document.write("Barney nasceu em " + (2016 - 40));







